package info.bookings;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FlightBooking {

	public static void main(String[] args) throws IOException, InterruptedException, AWTException {
		// TODO Auto-generated method stub
		
		ReadExcel abc=new ReadExcel();
		
		 String filePath = System.getProperty("user.dir")+"\\src";

		    //Call read file method of the class to read data

		abc.readExcel(filePath,"ExportExcel.xls","ExportExcel");

		System.setProperty("webdriver.chrome.driver", filePath+ "\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		
		driver.get(abc.url);
		
		System.out.println("Open URL: "+abc.url);
		
		Thread.sleep(1000);
		
		Robot rb = new Robot();

		WebElement a= driver.findElement(By.id("FromSector_show"));
		a.clear();
		a.sendKeys(abc.from);
		
		System.out.println("Enter From :"+abc.from);
		
		WebElement b=driver.findElement(By.id("Editbox13_show"));
		b.clear();
		b.sendKeys(abc.to);
		System.out.println("Enter To :"+abc.to);
		
		rb.keyPress(KeyEvent.VK_ESCAPE);
		rb.keyRelease(KeyEvent.VK_ESCAPE);
		
		
	/*	WebElement c=driver.findElement(By.id("ddate"));
		c.click();
		//c.sendKeys(abc.ddate);
		if(driver.findElement(By.xpath("//*[@class='month2']")).getText().equals(abc.ddate);
		
		
		
	WebElement d=driver.findElement(By.id("rdate"));
	d.clear();
	d.sendKeys(abc.rdate);
	
	*/
		
		
		
		
	}

}
